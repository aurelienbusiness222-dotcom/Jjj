package com.ti.mapolice

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.pdf.PdfDocument
import android.graphics.Color as AColor
import android.graphics.ImageDecoder
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.DataOutputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

// =====================================================================
//  MODÈLES
// =====================================================================
data class Seg(
    val t: String, val box: List<Float>, val color: Int,
    val bold: Boolean, val ul: Boolean, val ital: Boolean, val rule: Boolean,
    val chars: List<Pair<String, List<Float>>>,
    val latex: String = ""
)

class Glyph(val adv: Int, val cs: List<IntArray>) // contours aplatis x,y,x,y... en unités de police (1000/em)
class Cb(val c: String, val l: Float, val t: Float, val r: Float, val b: Float)

// =====================================================================
//  IA : reconnaissance via Gemini (texte, maths, physique, couleurs, mise en page)
// =====================================================================
const val PROMPT = """You are an expert OCR engine for HANDWRITTEN notes of any subject (French/English text, maths, physics, chemistry, signed numbers, units, equations, angles, fractions). Transcribe EVERYTHING that is handwritten.
Return ONLY JSON: {"segments":[{"kind":"text","text":"","box":[ymin,xmin,ymax,xmax],"color":"#RRGGBB","bold":false,"underline":false,"italic":false,"latex":"","chars":[{"c":"a","box":[ymin,xmin,ymax,xmax]}]}]}
Rules:
- All coordinates are integers 0-1000 normalized on the FULL image.
- One segment per visual line of writing. Anything written on its own level (numerator, denominator, exponent line, limits of a sum/integral) is its own segment so the layout is kept.
- Use Unicode for maths: √ ² ³ ⁿ ⁻¹ ₁ ₂ ∫ ∑ ∏ π Δ θ α β λ ∠ ° ± × ÷ · ≤ ≥ ≠ ≈ ≡ → ⇒ ⇔ ∞ ∈ ∉ ⊂ ∪ ∩ ∥ ⟂ and keep + − signs of signed numbers exactly.
- Fraction bars, square-root overbars, long straight rules: segment with "kind":"rule", empty text, box of the line. Do not create a rule for an underlined word, use "underline":true instead.
- "color" is the real ink color. "bold" if strokes are clearly thicker. 
- "chars": every non-space character of "text", in order, with its tight bounding box in the full image.
- "latex": LaTeX code of the segment when it contains maths/physics/chemistry (e.g. \frac{a}{b}), otherwise an empty string.
- Ignore paper lines, grid, margins and printed content."""

fun gemini(key: String, model: String, jpeg: ByteArray): String {
    val parts = JSONArray()
        .put(JSONObject().put("text", PROMPT))
        .put(JSONObject().put("inline_data", JSONObject().put("mime_type", "image/jpeg")
            .put("data", Base64.encodeToString(jpeg, Base64.NO_WRAP))))
    val body = JSONObject()
        .put("contents", JSONArray().put(JSONObject().put("parts", parts)))
        .put("generationConfig", JSONObject().put("responseMimeType", "application/json").put("temperature", 0.1))
    val c = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
        .openConnection() as HttpURLConnection
    c.requestMethod = "POST"; c.doOutput = true
    c.connectTimeout = 30000; c.readTimeout = 240000
    c.setRequestProperty("Content-Type", "application/json")
    c.setRequestProperty("x-goog-api-key", key.trim())
    c.outputStream.use { it.write(body.toString().toByteArray()) }
    val code = c.responseCode
    val txt = (if (code < 400) c.inputStream else c.errorStream).bufferedReader().readText()
    if (code >= 400) error("Erreur $code : ${txt.take(250)}")
    val ps = JSONObject(txt).getJSONArray("candidates").getJSONObject(0)
        .getJSONObject("content").getJSONArray("parts")
    return ps.getJSONObject(ps.length() - 1).getString("text")
}

fun box(a: JSONArray?): List<Float> =
    if (a != null && a.length() == 4) List(4) { a.getDouble(it).toFloat() } else listOf(0f, 0f, 0f, 0f)

fun parse(js: String): List<Seg> {
    val o = JSONObject(js.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim())
    val a = o.getJSONArray("segments")
    return List(a.length()) { i ->
        val s = a.getJSONObject(i)
        val cs = s.optJSONArray("chars")
        Seg(
            s.optString("text", ""), box(s.optJSONArray("box")),
            runCatching { AColor.parseColor(s.optString("color", "#000000")) }.getOrDefault(AColor.BLACK),
            s.optBoolean("bold"), s.optBoolean("underline"), s.optBoolean("italic"),
            s.optString("kind") == "rule",
            if (cs == null) emptyList() else List(cs.length()) { j ->
                val c = cs.getJSONObject(j)
                c.optString("c", "") to box(c.optJSONArray("box"))
            },
            s.optString("latex", "")
        )
    }
}

fun decode(ctx: Context, uri: Uri): Bitmap =
    ImageDecoder.decodeBitmap(ImageDecoder.createSource(ctx.contentResolver, uri)) { d, info, _ ->
        d.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
        val m = max(info.size.width, info.size.height)
        if (m > 3000) {
            val f = 3000f / m
            d.setTargetSize((info.size.width * f).toInt(), (info.size.height * f).toInt())
        }
    }

fun scaleTo(b: Bitmap, m: Int): Bitmap {
    val big = max(b.width, b.height)
    if (big <= m) return b
    val f = m.toFloat() / big
    return Bitmap.createScaledBitmap(b, (b.width * f).toInt(), (b.height * f).toInt(), true)
}

// =====================================================================
//  APPRENTISSAGE DE L'ÉCRITURE : découpe -> binarisation -> vectorisation
// =====================================================================
class Store(val f: File) {
    val m = HashMap<String, MutableList<Glyph>>()

    init { if (f.exists()) runCatching { load(f.readText()) } }

    fun load(txt: String) {
        val o = JSONObject(txt)
        val n = HashMap<String, MutableList<Glyph>>()
        o.keys().forEach { k ->
            val a = o.getJSONArray(k)
            n[k] = MutableList(a.length()) { i ->
                val g = a.getJSONObject(i)
                val c = g.getJSONArray("c")
                Glyph(g.getInt("w"), List(c.length()) { j ->
                    val p = c.getJSONArray(j)
                    IntArray(p.length()) { q -> p.getInt(q) }
                })
            }
        }
        m.clear(); m.putAll(n)
    }

    fun save() {
        val o = JSONObject()
        for ((k, v) in m) {
            val arr = JSONArray()
            for (g in v) {
                val cs = JSONArray()
                for (c in g.cs) cs.put(JSONArray(c.toList()))
                arr.put(JSONObject().put("w", g.adv).put("c", cs))
            }
            o.put(k, arr)
        }
        f.writeText(o.toString())
    }

    // Garde jusqu'à 8 variantes par caractère : jamais deux lettres identiques
    fun add(c: String, g: Glyph) {
        val l = m.getOrPut(c) { mutableListOf() }
        if (l.size < 8) l.add(g) else l[(0 until 8).random()] = g
    }
}

const val BASE = "acemnorsuvwxzABCDEFHIKLMNOPRSTUVWXYZ0123456789"

fun learn(b: Bitmap, segs: List<Seg>, st: Store): Int {
    var n = 0
    val w = b.width; val h = b.height
    for (s in segs) {
        if (s.rule) continue
        val cb = s.chars.filter { it.second.size == 4 && it.first.length == 1 && it.first != " " }
            .map { (c, x) -> Cb(c, x[1] / 1000f * w, x[0] / 1000f * h, x[3] / 1000f * w, x[2] / 1000f * h) }
        val bs = cb.filter { BASE.contains(it.c) && it.b > it.t && it.r > it.l }
        if (bs.size < 2) continue
        val hs = bs.map { it.b - it.t }.sorted()
        val ref = hs[(hs.size * 0.8f).toInt().coerceAtMost(hs.size - 1)]
        val baseline = bs.map { it.b }.sorted()[bs.size / 2]
        val sc = 700f / ref
        for (c in cb) glyph(b, c, baseline, sc)?.let { st.add(c.c, it); n++ }
    }
    return n
}

fun glyph(b: Bitmap, c: Cb, baseline: Float, sc: Float): Glyph? {
    val l = c.l.toInt().coerceIn(0, b.width - 2); val t = c.t.toInt().coerceIn(0, b.height - 2)
    val r = c.r.toInt().coerceIn(l + 1, b.width); val bt = c.b.toInt().coerceIn(t + 1, b.height)
    val w = r - l; val h = bt - t
    if (w < 6 || h < 6) return null
    val k = min(1f, 150f / max(w, h))
    val cw = max(3, (w * k).toInt()); val ch = max(3, (h * k).toInt())
    val bm = Bitmap.createScaledBitmap(Bitmap.createBitmap(b, l, t, w, h), cw, ch, true)
    val px = IntArray(cw * ch); bm.getPixels(px, 0, cw, 0, 0, cw, ch)
    val lum = IntArray(px.size) { val p = px[it]; (((p shr 16) and 255) * 30 + ((p shr 8) and 255) * 59 + (p and 255) * 11) / 100 }
    if (lum.max() - lum.min() < 40) return null
    // seuil d'Otsu
    val hist = IntArray(256); lum.forEach { hist[it]++ }
    var sum = 0L; for (i in 0..255) sum += i * hist[i].toLong()
    var wB = 0L; var sB = 0L; var best = 0.0; var th = 128
    for (i in 0..255) {
        wB += hist[i]; if (wB == 0L) continue
        val wF = lum.size - wB; if (wF == 0L) break
        sB += i * hist[i].toLong()
        val mB = sB.toDouble() / wB; val mF = (sum - sB).toDouble() / wF
        val v = wB.toDouble() * wF * (mB - mF) * (mB - mF)
        if (v > best) { best = v; th = i }
    }
    val ink = BooleanArray(cw * ch) { lum[it] <= th }
    // composantes connexes : on garde les grosses (corps + point du i), on vire les voisins qui débordent
    val lab = IntArray(ink.size) { -1 }; val areas = ArrayList<Int>()
    for (s0 in ink.indices) {
        if (!ink[s0] || lab[s0] != -1) continue
        val id = areas.size; var a = 0
        val st = ArrayDeque<Int>(); st.add(s0); lab[s0] = id
        while (st.isNotEmpty()) {
            val p = st.removeLast(); a++
            val x = p % cw; val y = p / cw
            for (dy in -1..1) for (dx in -1..1) {
                val nx = x + dx; val ny = y + dy
                if (nx < 0 || ny < 0 || nx >= cw || ny >= ch) continue
                val q = ny * cw + nx
                if (ink[q] && lab[q] == -1) { lab[q] = id; st.add(q) }
            }
        }
        areas.add(a)
    }
    if (areas.isEmpty()) return null
    val mx = areas.max()
    val mask = BooleanArray(cw * ch) // origine en bas (y vers le haut)
    var tot = 0
    for (row in 0 until ch) for (x in 0 until cw) {
        val id = lab[row * cw + x]
        if (id >= 0 && areas[id] >= max(6, (mx * 0.1).toInt())) { mask[(ch - 1 - row) * cw + x] = true; tot++ }
    }
    if (tot < 15 || tot > cw * ch * 0.8) return null
    val kx = cw.toFloat() / w; val ky = ch.toFloat() / h
    val cs = ArrayList<IntArray>()
    for (lp in loops(mask, cw, ch)) {
        val q = rdp(lp, 1.0)
        if (q.size < 3) continue
        val f = IntArray(q.size * 2)
        q.forEachIndexed { i, p ->
            val xu = p[0] / kx * sc
            val yo = t + (ch - p[1]) / ky
            f[i * 2] = xu.toInt(); f[i * 2 + 1] = ((baseline - yo) * sc).toInt()
        }
        cs.add(f)
    }
    if (cs.isEmpty()) return null
    var x0 = Int.MAX_VALUE; var x1 = Int.MIN_VALUE; var y0 = Int.MAX_VALUE; var y1 = Int.MIN_VALUE
    for (f in cs) for (i in 0 until f.size / 2) {
        x0 = min(x0, f[i * 2]); x1 = max(x1, f[i * 2]); y0 = min(y0, f[i * 2 + 1]); y1 = max(y1, f[i * 2 + 1])
    }
    if (y0 < -450 || y1 > 1100 || x1 - x0 > 1200) return null
    for (f in cs) for (i in 0 until f.size / 2) f[i * 2] = f[i * 2] - x0 + 40
    return Glyph(max(120, x1 - x0 + 80), cs)
}

// Contours = arêtes entre pixels encre / non-encre, encre à droite (horaire pour l'extérieur) => trous automatiquement inversés
fun loops(m: BooleanArray, w: Int, h: Int): List<List<IntArray>> {
    fun ink(x: Int, y: Int) = x in 0 until w && y in 0 until h && m[y * w + x]
    fun key(x: Int, y: Int) = x * 1024 + y
    val e = HashMap<Int, ArrayList<Int>>()
    fun add(x1: Int, y1: Int, x2: Int, y2: Int) { e.getOrPut(key(x1, y1)) { ArrayList() }.add(key(x2, y2)) }
    for (y in 0 until h) for (x in 0 until w) {
        if (!m[y * w + x]) continue
        if (!ink(x, y + 1)) add(x, y + 1, x + 1, y + 1)
        if (!ink(x, y - 1)) add(x + 1, y, x, y)
        if (!ink(x - 1, y)) add(x, y, x, y + 1)
        if (!ink(x + 1, y)) add(x + 1, y + 1, x + 1, y)
    }
    val out = ArrayList<List<IntArray>>()
    while (e.isNotEmpty()) {
        val start = e.keys.first(); var cur = start
        val pts = ArrayList<IntArray>()
        do {
            pts.add(intArrayOf(cur / 1024, cur % 1024))
            val l = e[cur] ?: break
            val nx = l.removeAt(l.size - 1)
            if (l.isEmpty()) e.remove(cur)
            cur = nx
        } while (cur != start)
        if (pts.size >= 4) out.add(pts)
    }
    return out
}

fun seg(q: List<IntArray>, a: Int, b: Int, eps: Double, keep: BooleanArray) {
    var mi = -1; var md = eps
    val ax = q[a][0].toDouble(); val ay = q[a][1].toDouble()
    val dx = q[b][0] - ax; val dy = q[b][1] - ay; val len = hypot(dx, dy)
    for (i in a + 1 until b) {
        val d = if (len == 0.0) hypot(q[i][0] - ax, q[i][1] - ay) else abs(dy * (q[i][0] - ax) - dx * (q[i][1] - ay)) / len
        if (d > md) { md = d; mi = i }
    }
    if (mi >= 0) { keep[mi] = true; seg(q, a, mi, eps, keep); seg(q, mi, b, eps, keep) }
}

fun rdp(p: List<IntArray>, eps: Double): List<IntArray> {
    if (p.size < 4) return p
    val q = p + listOf(p[0])
    var f = 0; var fd = -1.0
    for (i in p.indices) { val d = hypot((p[i][0] - p[0][0]).toDouble(), (p[i][1] - p[0][1]).toDouble()); if (d > fd) { fd = d; f = i } }
    val keep = BooleanArray(q.size); keep[0] = true; keep[f] = true; keep[q.lastIndex] = true
    seg(q, 0, f, eps, keep); seg(q, f, q.lastIndex, eps, keep)
    return q.indices.filter { keep[it] && it < q.lastIndex }.map { q[it] }
}

// =====================================================================
//  ÉCRITURE D'UN VRAI FICHIER .TTF (utilisable dans Word, Pages, Canva...)
// =====================================================================
class G(val cp: Int, val adv: Int, val cs: List<IntArray>)

fun be(f: DataOutputStream.() -> Unit): ByteArray {
    val bo = ByteArrayOutputStream(); DataOutputStream(bo).f(); return bo.toByteArray()
}
fun pad4(b: ByteArray) = if (b.size % 4 == 0) b else b.copyOf(b.size + 4 - b.size % 4)
fun csum(b: ByteArray): Long {
    val p = pad4(b); var s = 0L; var i = 0
    while (i < p.size) {
        s += ((p[i].toLong() and 255) shl 24) or ((p[i + 1].toLong() and 255) shl 16) or
            ((p[i + 2].toLong() and 255) shl 8) or (p[i + 3].toLong() and 255)
        i += 4
    }
    return s and 0xFFFFFFFFL
}

fun ttf(fam: String, glyphs: List<G>): ByteArray {
    val gs = listOf(G(-1, 500, emptyList()), G(32, 280, emptyList())) +
        glyphs.filter { it.cp in 33..0xFFFF }.distinctBy { it.cp }.sortedBy { it.cp }
    val n = gs.size
    var xMin = 0; var yMin = 0; var xMax = 1000; var yMax = 800; var maxP = 0; var maxC = 0; var advMax = 500
    val glyf = ByteArrayOutputStream(); val offs = ArrayList<Int>(); val lsb = ArrayList<Int>()
    for (g in gs) {
        offs.add(glyf.size()); advMax = max(advMax, g.adv)
        if (g.cs.isEmpty()) { lsb.add(0); continue }
        val xs = ArrayList<Int>(); val ys = ArrayList<Int>()
        for (c in g.cs) for (i in 0 until c.size / 2) { xs.add(c[i * 2]); ys.add(c[i * 2 + 1]) }
        xMin = min(xMin, xs.min()); yMin = min(yMin, ys.min()); xMax = max(xMax, xs.max()); yMax = max(yMax, ys.max())
        maxP = max(maxP, xs.size); maxC = max(maxC, g.cs.size); lsb.add(xs.min())
        val gb = be {
            writeShort(g.cs.size); writeShort(xs.min()); writeShort(ys.min()); writeShort(xs.max()); writeShort(ys.max())
            var e = -1; for (c in g.cs) { e += c.size / 2; writeShort(e) }
            writeShort(0)
            repeat(xs.size) { writeByte(1) }
            var px = 0; for (x in xs) { writeShort(x - px); px = x }
            var py = 0; for (y in ys) { writeShort(y - py); py = y }
        }
        glyf.write(pad4(gb))
    }
    offs.add(glyf.size())
    val cm = gs.mapIndexedNotNull { i, g -> if (g.cp > 0) g.cp to i else null }
    val sc = cm.size + 1
    var es = 1; var sel = 0; while (es * 2 <= sc) { es *= 2; sel++ }
    val cmap = be {
        writeShort(0); writeShort(1); writeShort(3); writeShort(1); writeInt(12)
        writeShort(4); writeShort(16 + 8 * sc); writeShort(0); writeShort(sc * 2); writeShort(es * 2); writeShort(sel); writeShort(sc * 2 - es * 2)
        cm.forEach { writeShort(it.first) }; writeShort(0xFFFF)
        writeShort(0)
        cm.forEach { writeShort(it.first) }; writeShort(0xFFFF)
        cm.forEach { writeShort((it.second - it.first) and 0xFFFF) }; writeShort(1)
        repeat(sc) { writeShort(0) }
    }
    val head = be {
        writeInt(0x00010000); writeInt(0x00010000); writeInt(0); writeInt(0x5F0F3CF5)
        writeShort(3); writeShort(1000); writeLong(0); writeLong(0)
        writeShort(xMin); writeShort(yMin); writeShort(xMax); writeShort(yMax)
        writeShort(0); writeShort(8); writeShort(2); writeShort(1); writeShort(0)
    }
    val hhea = be {
        writeInt(0x00010000); writeShort(800); writeShort(-250); writeShort(0); writeShort(advMax)
        writeShort(0); writeShort(0); writeShort(xMax); writeShort(1); writeShort(0); writeShort(0)
        repeat(4) { writeShort(0) }; writeShort(0); writeShort(n)
    }
    val maxp = be {
        writeInt(0x00010000); writeShort(n); writeShort(maxP); writeShort(maxC)
        writeShort(0); writeShort(0); writeShort(2); repeat(8) { writeShort(0) }
    }
    val hmtx = be { gs.forEachIndexed { i, g -> writeShort(g.adv); writeShort(lsb[i]) } }
    val loca = be { offs.forEach { writeInt(it) } }
    val os2 = be {
        writeShort(4); writeShort(500); writeShort(400); writeShort(5); writeShort(0)
        repeat(10) { writeShort(0) }; writeShort(0); repeat(10) { writeByte(0) }
        writeInt(3); repeat(3) { writeInt(0) }; write("NONE".toByteArray())
        writeShort(0x40); writeShort(32); writeShort(0xFFFF)
        writeShort(800); writeShort(-250); writeShort(0); writeShort(1000); writeShort(300)
        writeInt(1); writeInt(0); writeShort(450); writeShort(700); writeShort(0); writeShort(32); writeShort(1)
    }
    val post = be { writeInt(0x00030000); writeInt(0); writeShort(-100); writeShort(50); writeInt(0); repeat(4) { writeInt(0) } }
    val names = listOf(1 to fam, 2 to "Regular", 4 to fam, 6 to fam.replace(" ", ""))
    val strs = names.map { it.second.toByteArray(Charsets.UTF_16BE) }
    val nameT = be {
        writeShort(0); writeShort(names.size); writeShort(6 + 12 * names.size)
        var o = 0
        names.forEachIndexed { i, nm -> writeShort(3); writeShort(1); writeShort(0x409); writeShort(nm.first); writeShort(strs[i].size); writeShort(o); o += strs[i].size }
        strs.forEach { write(it) }
    }
    val tb = java.util.TreeMap<String, ByteArray>()
    tb["OS/2"] = os2; tb["cmap"] = cmap; tb["glyf"] = glyf.toByteArray(); tb["head"] = head; tb["hhea"] = hhea
    tb["hmtx"] = hmtx; tb["loca"] = loca; tb["maxp"] = maxp; tb["name"] = nameT; tb["post"] = post
    var off = 12 + 16 * tb.size
    val dir = be {
        writeInt(0x00010000); writeShort(tb.size); writeShort(128); writeShort(3); writeShort(tb.size * 16 - 128)
        for ((k, v) in tb) { write(k.toByteArray()); writeInt(csum(v).toInt()); writeInt(off); writeInt(v.size); off += pad4(v).size }
    }
    val bo = ByteArrayOutputStream(); bo.write(dir); tb.values.forEach { bo.write(pad4(it)) }
    val all = bo.toByteArray()
    var ho = 12 + 16 * tb.size
    for ((k, v) in tb) { if (k == "head") break; ho += pad4(v).size }
    val adj = (0xB1B0AFBAL - csum(all)) and 0xFFFFFFFFL
    for (i in 0..3) all[ho + 8 + i] = (adj shr (24 - 8 * i)).toByte()
    return all
}

// La variante k de la police prend la k-ième variante de chaque lettre
fun fontBytes(st: Store, k: Int, fam: String): ByteArray? {
    val gl = st.m.mapNotNull { (c, v) ->
        if (c.length == 1 && v.isNotEmpty()) { val g = v[k % v.size]; G(c[0].code, g.adv, g.cs) } else null
    }
    return if (gl.isEmpty()) null else ttf(fam, gl)
}

fun saveFile(ctx: Context, name: String, mime: String, data: ByteArray) {
    val v = ContentValues().apply {
        put(MediaStore.Downloads.DISPLAY_NAME, name)
        put(MediaStore.Downloads.MIME_TYPE, mime)
        put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
    }
    val u = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v) ?: error("Enregistrement impossible")
    ctx.contentResolver.openOutputStream(u)!!.use { it.write(data) }
}

// =====================================================================
//  OUTILS : couleur d'encre, hors-ligne, historique, exports PDF / Word
// =====================================================================
fun hex(c: Int) = String.format("%06X", c and 0xFFFFFF)

fun inkColor(b: Bitmap, r: Rect): Int {
    val l = r.left.coerceIn(0, b.width - 1); val t = r.top.coerceIn(0, b.height - 1)
    val w = r.width().coerceIn(1, b.width - l); val h = r.height().coerceIn(1, b.height - t)
    val px = IntArray(w * h); b.getPixels(px, 0, w, l, t, w, h)
    val lum = IntArray(px.size) { (((px[it] shr 16) and 255) * 30 + ((px[it] shr 8) and 255) * 59 + (px[it] and 255) * 11) / 100 }
    val lo = lum.min(); val hi = lum.max()
    if (hi - lo < 40) return AColor.BLACK
    val lim = lo + (hi - lo) * 0.3
    var rr = 0L; var gg = 0L; var bb = 0L; var n = 0
    for (i in px.indices) if (lum[i] <= lim) { rr += (px[i] shr 16) and 255; gg += (px[i] shr 8) and 255; bb += px[i] and 255; n++ }
    return if (n == 0) AColor.BLACK else AColor.rgb((rr / n).toInt(), (gg / n).toInt(), (bb / n).toInt())
}

// Couleur réellement mesurée sur la photo (plus fiable que celle estimée par l'IA)
fun refine(b: Bitmap, segs: List<Seg>): List<Seg> = segs.map { s ->
    val r = Rect((s.box[1] / 1000f * b.width).toInt(), (s.box[0] / 1000f * b.height).toInt(),
        (s.box[3] / 1000f * b.width).toInt(), (s.box[2] / 1000f * b.height).toInt())
    if (r.width() < 2 || r.height() < 1) s else s.copy(color = inkColor(b, r))
}

// Mode hors-ligne : ML Kit (sur le téléphone, sans Internet, sans maths)
suspend fun offline(b: Bitmap): List<Seg> {
    val rec = com.google.mlkit.vision.text.TextRecognition.getClient(com.google.mlkit.vision.text.latin.TextRecognizerOptions.DEFAULT_OPTIONS)
    val res = suspendCancellableCoroutine<com.google.mlkit.vision.text.Text> { c ->
        rec.process(com.google.mlkit.vision.common.InputImage.fromBitmap(b, 0))
            .addOnSuccessListener { c.resume(it) }.addOnFailureListener { c.resumeWithException(it) }
    }
    val w = b.width.toFloat(); val h = b.height.toFloat()
    fun bx(r: Rect) = listOf(r.top / h * 1000, r.left / w * 1000, r.bottom / h * 1000, r.right / w * 1000)
    val out = ArrayList<Seg>()
    for (blk in res.textBlocks) for (ln in blk.lines) {
        val r = ln.boundingBox ?: continue
        val ch = ln.elements.flatMap { it.symbols }.mapNotNull { sy -> sy.boundingBox?.let { sy.text to bx(it) } }
        out.add(Seg(ln.text, bx(r), AColor.BLACK, false, false, false, false, ch))
    }
    return out
}

fun geminiRetry(key: String, model: String, jpeg: ByteArray): String {
    var last: Exception? = null
    for (m in listOf(model, model, "gemini-2.5-flash-lite")) {
        try { return gemini(key, m, jpeg) } catch (e: Exception) {
            last = e
            val t = e.message ?: ""
            if (e is java.net.UnknownHostException || (t.startsWith("Erreur 4") && !t.startsWith("Erreur 429"))) break
            Thread.sleep(2500)
        }
    }
    throw last ?: Exception("Échec")
}

fun segsJson(s: List<Seg>): String {
    val a = JSONArray()
    for (x in s) a.put(
        JSONObject().put("kind", if (x.rule) "rule" else "text").put("text", x.t)
            .put("box", JSONArray(x.box.map { it.toDouble() })).put("color", "#" + hex(x.color))
            .put("bold", x.bold).put("underline", x.ul).put("italic", x.ital).put("latex", x.latex)
            .put("chars", JSONArray().apply { x.chars.forEach { (c, b) -> put(JSONObject().put("c", c).put("box", JSONArray(b.map { it.toDouble() }))) } })
    )
    return JSONObject().put("segments", a).toString()
}

fun scansDir(ctx: Context) = File(ctx.filesDir, "scans").apply { mkdirs() }

fun saveScan(ctx: Context, jpeg: ByteArray, s: List<Seg>) {
    val id = System.currentTimeMillis().toString()
    File(scansDir(ctx), "$id.jpg").writeBytes(jpeg)
    File(scansDir(ctx), "$id.json").writeText(segsJson(s))
}

fun styledText(t: String, fams: List<FontFamily>) = buildAnnotatedString {
    t.forEach { ch -> if (fams.isEmpty()) append(ch) else withStyle(SpanStyle(fontFamily = fams.random())) { append(ch) } }
}

fun exportPdf(ctx: Context, b: Bitmap, segs: List<Seg>, faces: List<Typeface>) {
    val pw = 595; val ph = (pw * b.height.toFloat() / b.width).toInt()
    val pdf = PdfDocument()
    val pg = pdf.startPage(PdfDocument.PageInfo.Builder(pw, ph, 1).create())
    val cv = pg.canvas; cv.drawColor(AColor.WHITE)
    for (s in segs) {
        val x = s.box[1] / 1000f * pw; val y = s.box[0] / 1000f * ph
        val w = (s.box[3] - s.box[1]) / 1000f * pw; val h = (s.box[2] - s.box[0]) / 1000f * ph
        val p = Paint(Paint.ANTI_ALIAS_FLAG); p.color = s.color
        if (s.rule) { cv.drawRect(x, y, x + w, y + max(h, 1.5f), p); continue }
        val fs = min(h * 0.8f, w / (max(1, s.t.length) * 0.45f)).coerceAtLeast(6f)
        p.textSize = fs; p.isFakeBoldText = s.bold; p.isUnderlineText = s.ul
        if (s.ital) p.textSkewX = -0.25f
        var cx = x
        for (ch in s.t) {
            if (faces.isNotEmpty()) p.typeface = faces.random()
            val t = ch.toString(); cv.drawText(t, cx, y + fs * 0.85f, p); cx += p.measureText(t)
        }
    }
    pdf.finishPage(pg)
    val bo = ByteArrayOutputStream(); pdf.writeTo(bo); pdf.close()
    saveFile(ctx, "MaPolice-${System.currentTimeMillis() / 1000}.pdf", "application/pdf", bo.toByteArray())
}

fun xml(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

// Word : un paragraphe par ligne, décalage et espacement reproduits, police "MaPolice 1" (à installer d'abord)
fun exportDocx(ctx: Context, b: Bitmap, segs: List<Seg>) {
    val fam = "MaPolice 1"
    val pw = 595f; val ph = pw * b.height / b.width
    val sb = StringBuilder(); var cur = 28f
    for (s in segs.sortedWith(compareBy({ it.box[0] }, { it.box[1] }))) {
        val x = s.box[1] / 1000f * pw; val y = s.box[0] / 1000f * ph
        val w = (s.box[3] - s.box[1]) / 1000f * pw; val h = (s.box[2] - s.box[0]) / 1000f * ph
        val before = (max(0f, y - cur) * 20).toInt(); val left = (x * 20).toInt()
        if (s.rule) {
            val right = (max(0f, pw - x - w) * 20).toInt()
            sb.append("<w:p><w:pPr><w:pBdr><w:bottom w:val=\"single\" w:sz=\"8\" w:space=\"1\" w:color=\"${hex(s.color)}\"/></w:pBdr><w:spacing w:before=\"$before\" w:after=\"0\" w:line=\"20\" w:lineRule=\"exact\"/><w:ind w:left=\"$left\" w:right=\"$right\"/></w:pPr></w:p>")
            cur = y + 2f; continue
        }
        val fs = min(h * 0.8f, w / (max(1, s.t.length) * 0.45f)).coerceIn(6f, 72f)
        val rpr = "<w:rFonts w:ascii=\"$fam\" w:hAnsi=\"$fam\" w:cs=\"$fam\"/>" + (if (s.bold) "<w:b/>" else "") +
            (if (s.ital) "<w:i/>" else "") + "<w:color w:val=\"${hex(s.color)}\"/><w:sz w:val=\"${(fs * 2).toInt()}\"/>" +
            (if (s.ul) "<w:u w:val=\"single\"/>" else "")
        sb.append("<w:p><w:pPr><w:spacing w:before=\"$before\" w:after=\"0\"/><w:ind w:left=\"$left\"/></w:pPr><w:r><w:rPr>$rpr</w:rPr><w:t xml:space=\"preserve\">${xml(s.t)}</w:t></w:r></w:p>")
        cur = y + fs * 1.25f
    }
    val head = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
    val doc = head + "<w:document xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\"><w:body>$sb" +
        "<w:sectPr><w:pgSz w:w=\"11906\" w:h=\"16838\"/><w:pgMar w:top=\"560\" w:right=\"0\" w:bottom=\"560\" w:left=\"0\" w:header=\"0\" w:footer=\"0\" w:gutter=\"0\"/></w:sectPr></w:body></w:document>"
    val bo = ByteArrayOutputStream()
    java.util.zip.ZipOutputStream(bo).use { z ->
        fun put(n: String, t: String) { z.putNextEntry(java.util.zip.ZipEntry(n)); z.write(t.toByteArray()); z.closeEntry() }
        put("[Content_Types].xml", head + "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/word/document.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml\"/></Types>")
        put("_rels/.rels", head + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"word/document.xml\"/></Relationships>")
        put("word/document.xml", doc)
    }
    saveFile(ctx, "MaPolice-${System.currentTimeMillis() / 1000}.docx",
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document", bo.toByteArray())
}

// =====================================================================
//  INTERFACE
// =====================================================================
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // "Partager" une photo depuis la Galerie vers MaPolice
        @Suppress("DEPRECATION")
        val shared = if (intent?.action == Intent.ACTION_SEND) intent.getParcelableExtra<Uri>(Intent.EXTRA_STREAM) else null
        setContent { MaterialTheme { Surface { App(shared) } } }
    }
}

@Composable
fun App(shared: Uri?) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val clip = LocalClipboardManager.current
    val prefs = remember { ctx.getSharedPreferences("p", 0) }
    var key by remember { mutableStateOf(prefs.getString("key", "") ?: "") }
    var model by remember { mutableStateOf(prefs.getString("model", "gemini-2.5-flash") ?: "gemini-2.5-flash") }
    val store = remember { Store(File(ctx.filesDir, "glyphs.json")) }
    var fams by remember { mutableStateOf(listOf<FontFamily>()) }
    var faces by remember { mutableStateOf(listOf<Typeface>()) }
    var count by remember { mutableStateOf(store.m.size) }
    var bmp by remember { mutableStateOf<Bitmap?>(null) }
    var segs by remember { mutableStateOf(listOf<Seg>()) }
    var busy by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf("") }
    var ask by remember { mutableStateOf(false) }
    var reset by remember { mutableStateOf(false) }
    var useFont by remember { mutableStateOf(true) }
    var camUri by remember { mutableStateOf<Uri?>(null) }
    var tab by remember { mutableStateOf(0) }
    var hv by remember { mutableStateOf(0) }
    var test by remember { mutableStateOf("Bonjour ! x² + 3x − 4 = 0") }

    fun rebuild() {
        val nv = (store.m.values.maxOfOrNull { it.size } ?: 0).coerceIn(0, 3)
        val lf = mutableListOf<FontFamily>(); val lt = mutableListOf<Typeface>()
        for (k in 0 until nv) fontBytes(store, k, "MaPolice ${k + 1}")?.let {
            val f = File(ctx.cacheDir, "v${k}_${System.currentTimeMillis()}.ttf")
            f.writeBytes(it); val tf = Typeface.createFromFile(f); lt.add(tf); lf.add(FontFamily(tf))
        }
        fams = lf; faces = lt; count = store.m.size
    }

    fun job(ok: String, f: () -> Unit) {
        scope.launch {
            busy = true
            try { withContext(Dispatchers.IO) { f() }; msg = ok } catch (e: Exception) { msg = e.message ?: "Erreur" }
            busy = false
        }
    }

    fun run(uri: Uri) {
        scope.launch {
            busy = true; msg = ""; tab = 0
            try {
                val b = withContext(Dispatchers.IO) { decode(ctx, uri) }
                val jp = withContext(Dispatchers.IO) {
                    val bo = ByteArrayOutputStream(); scaleTo(b, 2400).compress(Bitmap.CompressFormat.JPEG, 88, bo); bo.toByteArray()
                }
                var s: List<Seg> = emptyList()
                try {
                    if (key.isBlank()) error("pas de clé")
                    s = withContext(Dispatchers.IO) { parse(geminiRetry(key, model, jp)) }
                } catch (e: Exception) {
                    msg = "Mode hors-ligne (${(e.message ?: "").take(60)}) : texte simple, sans maths."
                    s = offline(b)
                }
                s = withContext(Dispatchers.IO) { refine(b, s) }
                bmp = b; segs = s; ask = true
                withContext(Dispatchers.IO) { saveScan(ctx, jp, s) }; hv++
            } catch (e: Exception) { msg = e.message ?: "Erreur" }
            busy = false
        }
    }

    val cam = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok -> if (ok) camUri?.let { run(it) } }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u -> u?.let { run(it) } }
    val restore = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u ->
        u?.let {
            job("Police restaurée") {
                val t = ctx.contentResolver.openInputStream(it)!!.bufferedReader().readText()
                store.load(t); store.save(); rebuild()
            }
        }
    }
    LaunchedEffect(Unit) { withContext(Dispatchers.IO) { runCatching { rebuild() } } }
    LaunchedEffect(shared) { shared?.let { run(it) } }

    Column(Modifier.systemBarsPadding()) {
        ScrollableTabRow(selectedTabIndex = tab, edgePadding = 8.dp) {
            listOf("Scanner", "Ma police", "Historique", "Réglages").forEachIndexed { i, t ->
                Tab(tab == i, { tab = i }, text = { Text(t, maxLines = 1) })
            }
        }
        Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (busy) Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CircularProgressIndicator(Modifier.size(24.dp)); Text("Un instant…")
            }
            if (msg.isNotBlank()) Text(msg, color = MaterialTheme.colorScheme.primary)

            when (tab) {
                0 -> {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(enabled = !busy, onClick = {
                            val v = ContentValues().apply {
                                put(MediaStore.Images.Media.DISPLAY_NAME, "mapolice_${System.currentTimeMillis()}.jpg")
                                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/MaPolice")
                            }
                            val u = ctx.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v)
                            if (u != null) { camUri = u; cam.launch(u) }
                        }) { Text("📷 Photo") }
                        Button(enabled = !busy, onClick = { pick.launch("image/*") }) { Text("🖼 Galerie") }
                    }
                    if (key.isBlank()) Text("Sans clé API : mode hors-ligne (texte simple). Ajoute ta clé dans Réglages pour les maths, couleurs et mise en page complète.")
                    val b = bmp
                    if (b != null) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Switch(useFont && fams.isNotEmpty(), { useFont = it }, enabled = fams.isNotEmpty())
                            Spacer(Modifier.width(8.dp)); Text("Avec ma police")
                        }
                        Page(b, segs, if (useFont) fams else emptyList())
                        val plain = segs.filter { !it.rule }.sortedWith(compareBy({ it.box[0] }, { it.box[1] }))
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Button({ clip.setText(AnnotatedString(plain.joinToString("\n") { it.t })); msg = "Texte copié" }, Modifier.weight(1f), contentPadding = PaddingValues(4.dp)) { Text("Copier") }
                            Button({
                                clip.setText(AnnotatedString(plain.joinToString("\n") { if (it.latex.isNotBlank()) "\\(" + it.latex + "\\)" else it.t })); msg = "LaTeX copié"
                            }, Modifier.weight(1f), contentPadding = PaddingValues(4.dp)) { Text("LaTeX") }
                            Button({
                                val i = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, plain.joinToString("\n") { it.t }) }
                                ctx.startActivity(Intent.createChooser(i, null))
                            }, Modifier.weight(1f), contentPadding = PaddingValues(4.dp)) { Text("Partager") }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Button({ job("PDF enregistré dans Téléchargements") { exportPdf(ctx, b, segs, faces) } }, Modifier.weight(1f), contentPadding = PaddingValues(4.dp)) { Text("PDF") }
                            Button({ job("Word enregistré (installe d'abord MaPolice-1.ttf)") { exportDocx(ctx, b, segs) } }, Modifier.weight(1f), contentPadding = PaddingValues(4.dp)) { Text("Word") }
                        }
                        OutlinedButton({ ask = true }) { Text("Ajouter cette écriture à ma police") }
                    }
                }
                1 -> {
                    Text("Ma police : $count caractères appris", style = MaterialTheme.typography.titleMedium)
                    Text("Plus tu ajoutes de pages, plus la police est fidèle. Chaque lettre garde jusqu'à 8 variantes.")
                    val missing = remember(count) { "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789àéèêçùôî+−=()/.,".filter { !store.m.containsKey(it.toString()) } }
                    if (missing.isNotEmpty()) Text("Pas encore écrits : $missing")
                    OutlinedTextField(test, { test = it }, Modifier.fillMaxWidth(), label = { Text("Tester ma police") })
                    Text(styledText(test, fams), fontSize = 28.sp)
                    Button(enabled = count > 0 && !busy, onClick = {
                        job("Polices .ttf enregistrées dans Téléchargements (ouvre-les pour les installer)") {
                            val nv = (store.m.values.maxOfOrNull { it.size } ?: 1).coerceIn(1, 3)
                            for (k in 0 until nv) fontBytes(store, k, "MaPolice ${k + 1}")?.let { saveFile(ctx, "MaPolice-${k + 1}.ttf", "font/ttf", it) }
                        }
                    }) { Text("Exporter ma police (.ttf)") }
                    OutlinedButton(enabled = count > 0 && !busy, onClick = {
                        job("Sauvegarde enregistrée dans Téléchargements") { store.save(); saveFile(ctx, "MaPolice-sauvegarde.json", "application/json", store.f.readBytes()) }
                    }) { Text("Sauvegarder ma police") }
                    OutlinedButton(enabled = !busy, onClick = { restore.launch("*/*") }) { Text("Restaurer une sauvegarde") }
                    TextButton(enabled = count > 0, onClick = { reset = true }) { Text("Réinitialiser ma police") }
                }
                2 -> {
                    val items = remember(hv) { (scansDir(ctx).listFiles { f -> f.extension == "json" } ?: emptyArray()).sortedByDescending { it.name } }
                    if (items.isEmpty()) Text("Aucun scan pour l'instant.")
                    items.forEach { f ->
                        val id = f.nameWithoutExtension
                        val snippet = remember(id) { runCatching { parse(f.readText()).firstOrNull { !it.rule }?.t ?: "" }.getOrDefault("") }
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.FRANCE).format(Date(id.toLongOrNull() ?: 0L)), style = MaterialTheme.typography.bodySmall)
                                Text(snippet, maxLines = 1)
                            }
                            TextButton({
                                val bm = BitmapFactory.decodeFile(File(scansDir(ctx), "$id.jpg").path)
                                if (bm != null) { bmp = bm; segs = parse(f.readText()); tab = 0; msg = "" }
                            }) { Text("Ouvrir") }
                            TextButton({ f.delete(); File(scansDir(ctx), "$id.jpg").delete(); hv++ }) { Text("Suppr.") }
                        }
                    }
                }
                else -> {
                    OutlinedTextField(
                        key, { key = it; prefs.edit().putString("key", it).apply() }, Modifier.fillMaxWidth(), singleLine = true,
                        label = { Text("Clé API Gemini") }, visualTransformation = PasswordVisualTransformation()
                    )
                    Text("Clé gratuite : aistudio.google.com/apikey. Elle reste uniquement sur ton téléphone.")
                    OutlinedTextField(model, { model = it; prefs.edit().putString("model", it).apply() }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("Modèle") })
                    Text("Si l'IA est surchargée, l'app réessaie puis passe sur gemini-2.5-flash-lite. Sans Internet, elle bascule en mode hors-ligne.")
                }
            }
        }
    }

    if (ask && bmp != null) AlertDialog(
        onDismissRequest = { ask = false },
        title = { Text("Est-ce bien ton écriture ?") },
        text = { Text("Si oui, je m'en sers pour améliorer ta police : plus tu en ajoutes, plus elle devient fidèle et naturelle.") },
        confirmButton = {
            TextButton({
                ask = false
                val b = bmp!!; val s = segs
                scope.launch {
                    busy = true
                    val n = withContext(Dispatchers.IO) { val n = learn(b, s, store); store.save(); rebuild(); n }
                    msg = "$n lettres ajoutées à ta police"; busy = false
                }
            }) { Text("Oui, c'est moi") }
        },
        dismissButton = { TextButton({ ask = false }) { Text("Non") } }
    )
    if (reset) AlertDialog(
        onDismissRequest = { reset = false },
        title = { Text("Réinitialiser ?") },
        text = { Text("Toutes les lettres apprises seront effacées (pense à sauvegarder avant).") },
        confirmButton = { TextButton({ reset = false; job("Police réinitialisée") { store.m.clear(); store.save(); rebuild() } }) { Text("Effacer") } },
        dismissButton = { TextButton({ reset = false }) { Text("Annuler") } }
    )
}

@Composable
fun Page(b: Bitmap, segs: List<Seg>, fams: List<FontFamily>) {
    BoxWithConstraints(Modifier.fillMaxWidth()) {
        val d = LocalDensity.current
        val pw = with(d) { maxWidth.toPx() }
        val ph = pw * b.height / b.width
        Box(Modifier.width(maxWidth).height(with(d) { ph.toDp() }).background(Color.White)) {
            segs.forEach { s ->
                val x = (s.box[1] / 1000f * pw).toInt(); val y = (s.box[0] / 1000f * ph).toInt()
                val w = (s.box[3] - s.box[1]) / 1000f * pw; val h = (s.box[2] - s.box[0]) / 1000f * ph
                if (s.rule) {
                    Box(Modifier.offset { IntOffset(x, y) }.size(with(d) { w.toDp() }, with(d) { max(h, 3f).toDp() }).background(Color(s.color)))
                } else {
                    val fs = min(h * 0.8f, w / (max(1, s.t.length) * 0.45f)).coerceAtLeast(12f)
                    // une police différente au hasard pour chaque lettre => rendu naturel
                    val text = remember(s, fams) {
                        buildAnnotatedString {
                            s.t.forEach { ch ->
                                if (fams.isEmpty()) append(ch)
                                else withStyle(SpanStyle(fontFamily = fams.random())) { append(ch) }
                            }
                        }
                    }
                    Text(
                        text, Modifier.offset { IntOffset(x, y) }, color = Color(s.color),
                        fontSize = with(d) { fs.toSp() },
                        fontWeight = if (s.bold) FontWeight.Bold else null,
                        fontStyle = if (s.ital) FontStyle.Italic else null,
                        textDecoration = if (s.ul) TextDecoration.Underline else null,
                        softWrap = false, maxLines = 1
                    )
                }
            }
        }
    }
}
