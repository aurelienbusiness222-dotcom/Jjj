# MaPolice : compiler sur GitHub et installer (depuis le téléphone)

1. github.com > New repository > nom "mapolice" > Private > Create.
2. "uploading an existing file" > choisis MaPolice.zip (le zip tel quel) > Commit.
3. Add file > Create new file. Nom : `.github/workflows/build.yml`
   Colle le contenu du fichier build-from-zip.yml fourni dans la conversation > Commit.
4. Onglet Actions : le build démarre seul (5 à 8 min). Pastille verte = terminé.
5. Onglet Releases (colonne de droite du dépôt) > ouvre la dernière > télécharge MaPolice.apk.
6. Ouvre le fichier > "Autoriser l'installation depuis cette source" > Installer.
7. Dans l'app : Réglages > colle ta clé Gemini.

Mise à jour : remplace MaPolice.zip dans le dépôt (Add file > Upload files, même nom). Le build repart
et l'APK se réinstalle PAR-DESSUS l'ancien sans perdre ta police (signature fixe).
