package com.ti.manettefinder

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.*
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.InputDevice
import android.widget.*
import android.app.Activity

@SuppressLint("MissingPermission")
class MainActivity : Activity() {
    private lateinit var adapter: BluetoothAdapter
    private lateinit var status: TextView
    private lateinit var list: LinearLayout
    private val seen = LinkedHashMap<String, BluetoothDevice>()

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            when (i.action) {
                BluetoothDevice.ACTION_FOUND -> {
                    val d = i.device() ?: return
                    seen[d.address] = d; refresh()
                }
                BluetoothAdapter.ACTION_DISCOVERY_FINISHED -> status.text = "Scan terminé. ${seen.size} appareil(s)."
                BluetoothDevice.ACTION_BOND_STATE_CHANGED -> {
                    val st = i.getIntExtra(BluetoothDevice.EXTRA_BOND_STATE, -1)
                    if (st == BluetoothDevice.BOND_BONDED) status.text = "Appairé ! Ouvre Fortnite."
                    refresh()
                }
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun Intent.device(): BluetoothDevice? =
        if (Build.VERSION.SDK_INT >= 33) getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
        else getParcelableExtra<BluetoothDevice>(BluetoothDevice.EXTRA_DEVICE)

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        adapter = (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 100, 40, 40) }
        root.addView(TextView(this).apply { text = "Manette Finder"; textSize = 26f; setTypeface(null, Typeface.BOLD) })
        root.addView(TextView(this).apply {
            text = "1) Éteins la manette. 2) Maintiens SYNC 3 s (LED qui défilent). 3) Appuie sur Scanner."
            setPadding(0, 20, 0, 20)
        })
        root.addView(Button(this).apply { text = "Scanner les appareils"; setOnClickListener { scan() } })
        root.addView(Button(this).apply { text = "Ouvrir réglages Bluetooth"; setOnClickListener {
            startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) } })
        status = TextView(this).apply { setPadding(0, 20, 0, 20); text = "Prêt." }
        root.addView(status)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(ScrollView(this).apply { addView(list) })
        setContentView(root)
        val f = IntentFilter().apply {
            addAction(BluetoothDevice.ACTION_FOUND)
            addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED)
            addAction(BluetoothDevice.ACTION_BOND_STATE_CHANGED)
        }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, f, Context.RECEIVER_EXPORTED)
        else registerReceiver(receiver, f)
        ensurePerms()
        showPaired()
    }

    private fun ensurePerms() {
        val p = if (Build.VERSION.SDK_INT >= 31)
            arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
        else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        if (p.any { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }) requestPermissions(p, 1)
    }

    private fun scan() {
        if (!adapter.isEnabled) { status.text = "Active le Bluetooth d'abord."; startActivity(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)); return }
        seen.clear(); showPaired()
        adapter.cancelDiscovery()
        status.text = if (adapter.startDiscovery()) "Scan en cours…" else "Scan impossible (permissions ?)"
    }

    private fun showPaired() { adapter.bondedDevices?.forEach { seen[it.address] = it }; refresh() }

    private fun gamepads() = InputDevice.getDeviceIds().mapNotNull { InputDevice.getDevice(it) }
        .filter { (it.sources and InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD }.map { it.name }

    private fun refresh() {
        list.removeAllViews()
        val pads = gamepads()
        if (pads.isNotEmpty()) list.addView(TextView(this).apply { text = "🎮 Manette détectée par Android : ${pads.joinToString()}"; setPadding(0, 10, 0, 20) })
        seen.values.sortedByDescending { looksLikePad(it) }.forEach { d ->
            val bonded = d.bondState == BluetoothDevice.BOND_BONDED
            list.addView(Button(this).apply {
                text = (if (looksLikePad(d)) "🎮 " else "") + (d.name ?: "Sans nom") + "\n" + d.address + if (bonded) "  ✔ appairé" else ""
                setOnClickListener {
                    adapter.cancelDiscovery()
                    if (bonded) status.text = "Déjà appairé. Si ça ne marche pas : réglages BT → Oublier, puis refais SYNC."
                    else { status.text = "Appairage…"; d.createBond() }
                }
            })
        }
    }

    private fun looksLikePad(d: BluetoothDevice): Boolean {
        val n = (d.name ?: "").lowercase()
        return d.bluetoothClass?.majorDeviceClass == BluetoothClass.Device.Major.PERIPHERAL ||
            listOf("controller", "pro", "gamepad", "joy", "diswoe", "switch", "wireless").any { n.contains(it) }
    }

    override fun onDestroy() { unregisterReceiver(receiver); super.onDestroy() }
}
